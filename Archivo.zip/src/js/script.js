$('input').focus(function(){
    $(this).parents('p').addClass('focused');
  });
  
  $('input').blur(function(){
    var inputValue = $(this).val();
    if ( inputValue == "" ) {
      $(this).removeClass('filled');
      $(this).parents('p').removeClass('focused');  
    } else {
      $(this).addClass('filled');
    }
  })  
  $("input").on("change keypress keyup blur", function() {
      var id = $(this).attr("id");
      var idVal = $("#"+id).val();
      if(id == "name"){
          $("#nombreFirma").html(idVal);
      }else if(id == "puesto"){
        $("#puestoFirma").html(idVal);
      }else if(id == "telefono"){
          console.log(idVal.substr(0, 2))
       
        $("#telefonoFirma").html(idVal);
      }
 });

 function copyToClip(str) {
    function listener(e) {
      e.clipboardData.setData("text/html", str);
      e.clipboardData.setData("text/plain", str);
      e.preventDefault();
    }
    document.addEventListener("copy", listener);
    document.execCommand("copy");
    document.removeEventListener("copy", listener);
  };